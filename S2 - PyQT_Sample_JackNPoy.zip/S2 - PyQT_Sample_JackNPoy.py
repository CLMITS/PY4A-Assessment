import sys
from PyQt4 import QtGui, QtCore
from random import randint
class Window(QtGui.QMainWindow):
    cl=['Rock','Scissor','Paper']
    counter=0
    def __init__(self):
        super (Window, self).__init__()
        self.setGeometry(50,50,800,300)
        self.setWindowTitle("CLIMITS Rocks!")
        self.setWindowIcon(QtGui.QIcon('images/logo.png'))

        extractAction = QtGui.QAction("&Exit",self)
        extractAction.setShortcut("Ctrl+X")
        extractAction.setStatusTip("Leave The App")
        extractAction.triggered.connect(self.close_application)
        self.statusBar()
        mainMenu = self.menuBar()
        fileMenu = mainMenu.addMenu('&File')
        fileMenu.addAction(extractAction)
        self.home()

    def home(self):
        self.installEventFilter(self)

        lblt = QtGui.QLabel(self)
        lblt.setText("Please Choose Your Weapon")
        lblt.setScaledContents(True)
        lblt.resize(200, 50)
        lblt.move(50,50)

        lbl1 = QtGui.QLabel(self)
        lbl1.setPixmap(QtGui.QPixmap("images/RockV2.png"))
        lbl1.setScaledContents(True)
        lbl1.resize(200, 200)
        lbl1.move(150,90)

        lblvs = QtGui.QLabel(self)
        lblvs.setPixmap(QtGui.QPixmap("images/vs.png"))
        lblvs.setScaledContents(True)
        lblvs.resize(200, 200)
        lblvs.move(350,90)

        lblR = QtGui.QLabel(self)
        lblR.setPixmap(QtGui.QPixmap("images/Ready.png"))
        lblR.setScaledContents(True)
        lblR.resize(200, 90)
        lblR.move(350,0)

        lbl2 = QtGui.QLabel(self)
        lbl2.setPixmap(QtGui.QPixmap("images/rps.png"))
        lbl2.setScaledContents(True)
        lbl2.resize(200, 200)
        lbl2.move(550,90)

        btnR = QtGui.QPushButton("Rock",self)
        btnR.clicked.connect(lambda x: self.game_start(0))
        btnR.resize(btnR.minimumSizeHint())
        btnR.move(50,100)
        btnR.installEventFilter(self)

        btnP = QtGui.QPushButton("Scissor",self)
        btnP.clicked.connect(lambda x: self.game_start(1))
        btnP.resize(btnP.minimumSizeHint())
        btnP.move(50,150)
        btnP.installEventFilter(self)

        btnS = QtGui.QPushButton("Paper",self)
        btnS.clicked.connect(lambda x: self.game_start(2))
        btnS.resize(btnS.minimumSizeHint())
        btnS.move(50,200)
        btnS.installEventFilter(self)

        screen_center = lambda self: QtGui.QApplication.desktop().screen().rect().center() - self.rect().center()
        self.move(screen_center(self))

        self.show()

    def eventFilter(self, object, event):

        if event.type() == QtCore.QEvent.HoverMove:

            if "Window" in str(object):
                if self.counter==50 :
                    lblR = QtGui.QLabel(self)
                    lblR.setPixmap(QtGui.QPixmap("images/Ready.png"))
                    lblR.setScaledContents(True)
                    lblR.resize(200, 90)
                    lblR.move(350,0)
                    lblR.show()
                    self.counter=0
                else :
                    self.counter+=1
            else:
                lbl2 = QtGui.QLabel(self)
                lbl2.setPixmap(QtGui.QPixmap("images/rps.png"))
                lbl2.setScaledContents(True)
                lbl2.resize(200, 200)
                lbl2.move(550,90)
                lbl2.show()

                lbl1 = QtGui.QLabel(self)
                lbl1.setScaledContents(True)
                lbl1.resize(200, 200)
                lbl1.move(150,90)
                if object.text() == "Rock" :
                    lbl1.setPixmap(QtGui.QPixmap("images/RockV2.png"))
                    lbl1.show()
                elif object.text() == "Paper" :
                    lbl1.setPixmap(QtGui.QPixmap("images/PaperV2.png"))
                    lbl1.show()
                elif object.text() == "Scissor" :
                    lbl1.setPixmap(QtGui.QPixmap("images/ScissorV2.png"))
                    lbl1.show()
            return True
        else :
            pass

        return False



    def game_start(self,vRPS):
        c = randint(0,2) #0-Rock 1-Scissors 2-Paper
        lbl2 = QtGui.QLabel(self)
        img="images/"+"".join(self.cl[c:(c+1)])+"V2.png"
        lbl2.setPixmap(QtGui.QPixmap(img))
        lbl2.setScaledContents(True)
        lbl2.resize(200, 200)
        lbl2.move(550,90)
        lbl2.show()

        lblR = QtGui.QLabel(self)
        lblR.setScaledContents(True)
        lblR.resize(200, 90)
        lblR.move(350,0)

        if (c==vRPS)  :
            msg="\n----------DRAW---------- \n Computer: %s \n Player: %s \n----------DRAW----------\n"
            lblR.setPixmap(QtGui.QPixmap("images/Draw.png"))
            lblR.show()
            #QtGui.QMessageBox.question(self,"DRAW",msg % (self.cl[c:(c+1)],self.cl[(vRPS):vRPS+1]))

        elif (c==0 and vRPS==1) or (c==1 and vRPS==2) or (c==2 and vRPS==0) :
            msg="\n----------LOSE---------- \n Computer: %s \n Player: %s \n----------LOSE----------\n"
            lblR.setPixmap(QtGui.QPixmap("images/Lose.png"))
            lblR.show()
            #QtGui.QMessageBox.question(self,"YOU LOSE",msg % (self.cl[c:(c+1)],self.cl[(vRPS):vRPS+1]))

        elif (c==0 and vRPS==2) or (c==1 and vRPS==0) or (c==2 and vRPS==1) :
            msg="\n----------WIN---------- \n Computer: %s \n Player: %s \n----------WIN----------\n"
            lblR.setPixmap(QtGui.QPixmap("images/Win.png"))
            lblR.show()
            #QtGui.QMessageBox.question(self,"YOU WIN",msg % (self.cl[c:(c+1)],self.cl[(vRPS):vRPS+1]))


    def enlarge_window(self, state):
        if state == QtCore.Qt.Checked:
            self.setGeometry(50,50,1000,600)
            screen_center = lambda self: QtGui.QApplication.desktop().screen().rect().center() - self.rect().center()
            self.move(screen_center(self))
        else :
            self.setGeometry(50,50,500,500)
            screen_center = lambda self: QtGui.QApplication.desktop().screen().rect().center() - self.rect().center()
            self.move(screen_center(self))

    def closeEvent(self, QCloseEvent): ## Closing the Main Form (X)
        QCloseEvent.ignore()
        self.close_application()

    def close_application(self):
        choice = QtGui.QMessageBox.question(self,"Confirmation","Sure to exit?",QtGui.QMessageBox.Yes|QtGui.QMessageBox.No)
        if choice == QtGui.QMessageBox.Yes:
            print("Existing Window...")
            sys.exit()
        else:
            pass

def run():
    app=QtGui.QApplication(sys.argv)
    GUI=Window()
    sys.exit(app.exec_())
run()
